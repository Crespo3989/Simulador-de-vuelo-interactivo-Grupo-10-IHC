"""Textura cartográfica e iluminación artística, calculadas localmente."""
import numpy as np
from PIL import Image, ImageDraw, ImageFilter


class TierraColor:
    def __init__(self, geojson):
        width, height = 2048, 1024
        mask = Image.new('L', (width, height))
        painter = ImageDraw.Draw(mask)
        for feature in geojson['features']:
            g = feature['geometry']
            polygons = [g['coordinates']] if g['type'] == 'Polygon' else g['coordinates']
            for polygon in polygons:
                for index, ring in enumerate(polygon):
                    points = [((lon+180)/360*(width-1), (90-lat)/180*(height-1))
                              for lon, lat, *_ in ring]
                    painter.polygon(points, fill=255 if index == 0 else 0)
        land = np.asarray(mask, dtype=np.float32)/255
        coast = np.asarray(mask.filter(ImageFilter.GaussianBlur(5)), dtype=np.float32)/255
        lat = np.linspace(90, -90, height, dtype=np.float32)[:, None]
        lon = np.linspace(-180, 180, width, dtype=np.float32)[None, :]
        # Paleta estilizada, no clasificación climática o datos de elevación.
        variation = (np.sin(np.radians(lon*3))+np.cos(np.radians(lat*5)))*.5
        ocean = np.empty((height, width, 3), dtype=np.float32)
        for i, (base, shallow) in enumerate(zip((17, 66, 112), (22, 77, 86))):
            ocean[:, :, i] = base + coast*shallow + variation*3
        terrain = np.empty_like(ocean)
        for i, base in enumerate((73, 139, 101)):
            terrain[:, :, i] = base + variation*9
        ice = np.clip((np.abs(lat)-62)/15, 0, 1)[:, :, None]
        terrain = terrain*(1-ice) + np.array([219, 236, 234])*ice
        self.texture = np.clip(ocean*(1-land[:, :, None])+terrain*land[:, :, None], 0, 255).astype(np.uint8)
        self.geometry = None
        self.geometry_size = None

    def render(self, size, basis):
        """Intersección inversa de cada píxel con la esfera; sin polígonos mal recortados."""
        size = max(32, int(size))
        # Limitar resolución interna mantiene el movimiento fluido en equipos modestos.
        n = min(size, 560)
        if n != self.geometry_size:
            values = np.linspace(-1, 1, n, dtype=np.float32)
            x, screen_y = np.meshgrid(values, values)
            y = -screen_y
            rr = x*x+y*y
            z = np.sqrt(np.maximum(0, 1-rr))
            shade = .48 + .52*np.maximum(0, -.38*x+.44*y+.81*z)
            rim = np.power(1-z, 3)*.38
            self.geometry = (x, y, z, rr <= 1, shade, rim)
            self.geometry_size = n
        x, y, z, inside, shade, rim = self.geometry
        east, north, front = basis
        wx = east[0]*x+north[0]*y+front[0]*z
        wy = east[1]*x+north[1]*y+front[1]*z
        wz = east[2]*x+north[2]*y+front[2]*z
        longitude = np.arctan2(wy, wx)
        latitude = np.arcsin(np.clip(wz, -1, 1))
        h, w = self.texture.shape[:2]
        tx = np.clip(((longitude+np.pi)/(2*np.pi)*(w-1)).astype(int), 0, w-1)
        ty = np.clip(((np.pi/2-latitude)/np.pi*(h-1)).astype(int), 0, h-1)
        color = self.texture[ty, tx]*shade[:, :, None]
        color = color*(1-rim[:, :, None]) + np.array([66, 164, 226])*rim[:, :, None]
        rgba = np.zeros((n, n, 4), dtype=np.uint8)
        rgba[:, :, :3] = np.clip(color, 0, 255).astype(np.uint8)
        rgba[:, :, 3] = inside.astype(np.uint8)*255
        result = Image.fromarray(rgba)
        if size != n:
            result = result.resize((size, size), Image.Resampling.LANCZOS)
        return result
